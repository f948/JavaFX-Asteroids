/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroids.game;

import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 *
 * @author User
 */
public class AsteroidsGame extends Application {
    
     static Canvas canvas = new Canvas(1000,1000);
     static GraphicsContext context = canvas.getGraphicsContext2D(); 
     static Group root = new Group(canvas);
     static Scene scene = new Scene(root, 1000, 1000);
     Timer timer = new Timer();
     static Random rand = new Random();
    
     
     static Ship playerShip;
     static ArrayList<Asteroid> asteroids = new ArrayList<>();
     static ArrayList<Bullet> bullets = new ArrayList<>();
     static int row,col,i,j;
     static String direction="";
     static boolean playerCanFire=true;
     static double distX,distY,angle,velX,velY;
     static int asteroidNum,asteroidX,asteroidY,sectionNum,signX,signY,timesRun;
     
     public static class Ship{
         

            final int radius;
            int angle1,angle2,angle3;
            boolean hit;
            double centerX;
            double centerY;
            double velocityX;
            double velocityY;

            
            public Ship(){
                
                this.radius=15;
                this.hit=false;
                this.centerX=500;
                this.centerY=500;
                this.angle1=0;
                this.angle2=135;
                this.angle3= 225;
                this.velocityX=0;
                this.velocityY=0;

            }
        }
        
        public static class Asteroid{
            
            double centerX;
            double centerY;
            boolean hit;
       
            double velocityX;
            double velocityY;
            final int radius;

            
            public Asteroid(double x,double y,double velocityX,double velocityY,int radius){
                this.centerX=x;
                this.centerY=y;
                this.hit=false;
                this.velocityX=velocityX;
                this.velocityY=velocityY;
                this.radius=radius;
     
          
            }
        }
   
   
        
        public static class Bullet{
            
            double centerX;
            double centerY;
            boolean hit;
            double velocityX;
            double velocityY;
            final int radius;
            
            public Bullet(double x,double y,double velocityX,double velocityY){
                this.centerX=x;
                this.centerY=y;
                this.hit=false;
                this.velocityX=velocityX;
                this.velocityY=velocityY;
                this.radius=2;
            }
        }
        
        public static void startGame(){
        
        // clear all arrays 
        asteroids.clear();
        bullets.clear();
        
        // create player ship 
	playerShip = new Ship();

    }
        
        public static void generateAsteroids(){
            
            
            asteroidNum=rand.nextInt(3);
            sectionNum=rand.nextInt(4);
            
            // create asteroids in various sections 
            
            // left section
            if(sectionNum==0){
                asteroidX=-100;
                asteroidY=rand.nextInt(1200)-100;
                signX=1;
               signY=rand.nextInt(2);
            }
            
            // top section
            else if(sectionNum==1){
                asteroidX=rand.nextInt(1200)-100;
                asteroidY=-100;
                signX=rand.nextInt(2);
                signY=1;
               
                
            }
            // right section 
            else if(sectionNum==2){
                asteroidX=1100;
                asteroidY=rand.nextInt(1200)-100;
                signX=0;
                signY=rand.nextInt(2);
                
                
            }
            // bottom section 
            else if(sectionNum==3){
                asteroidX=rand.nextInt(1200)-100;
                asteroidY=1100;
                signX=rand.nextInt(2);
                signY=0;
            }
            
            angle = Math.random()*45;
                
            velX=Math.cos(angle)*2.8;
            velY=Math.sin(angle)*2.8;
                
            if(signX==0){
                velX=-velX;
            }
            if(signY==0){
                velY=-velY;
            }
                
            // small asteroid 
            if(asteroidNum==0){
                
                
                
                asteroids.add(new Asteroid(asteroidX,asteroidY,velX,velY,25));
                
                
                
            }
            
            // medium asteroid 
            else if(asteroidNum==1){
                
              
                
                asteroids.add(new Asteroid(asteroidX,asteroidY,velX,velY,50));
                
            }
            
            // large asteroid 
            else if(asteroidNum==2){

               asteroids.add(new Asteroid(asteroidX,asteroidY,velX,velY,100));
            }
        }
        public static void deleteObjects(){
            
            // delete asteroids 
            for(i=0;i<=asteroids.size()-1;i++){
                if(asteroids.get(i).hit || asteroids.get(i).centerX+asteroids.get(i).radius<=-200 || asteroids.get(i).centerY+asteroids.get(i).radius<=-200 || asteroids.get(i).centerX-asteroids.get(i).radius>=1200 || asteroids.get(i).centerY-asteroids.get(i).radius>=1200){
                    asteroids.remove(asteroids.get(i));
                }
            }
            
            // delete asteroids 
            for(i=0;i<=bullets.size()-1;i++){
                if(bullets.get(i).hit || bullets.get(i).centerX<=0 || bullets.get(i).centerY<=0 || bullets.get(i).centerX>=1000 || bullets.get(i).centerY>=1000){
                    bullets.remove(bullets.get(i));
                }
            }
        }
        
        public static void updateScreen(){
            
        // clear original screen
	context.clearRect(0,0,1000,1000);
				
	// redraw background 
	context.setFill(Color.BLACK);
	context.fillRect(0,0,1000,1000);
        
        if(direction=="left"){
            playerShip.angle1-=2;
            playerShip.angle2-=2;
            playerShip.angle3-=2;
        }
        
        else if(direction=="right"){
            playerShip.angle1+=2;
            playerShip.angle2+=2;
            playerShip.angle3+=2;
        }
        
        direction="";
        
        context.setStroke(Color.WHITE);
        
            if(!playerShip.hit){
            
                
                context.beginPath();
                
              
                context.moveTo(Math.cos(Math.toRadians(playerShip.angle1))*playerShip.radius+playerShip.centerX,Math.sin(Math.toRadians(playerShip.angle1))*playerShip.radius+playerShip.centerY);
                context.lineTo(Math.cos(Math.toRadians(playerShip.angle2))*playerShip.radius+playerShip.centerX,Math.sin(Math.toRadians(playerShip.angle2))*playerShip.radius+playerShip.centerY);
                context.lineTo(Math.cos(Math.toRadians(playerShip.angle3))*playerShip.radius+playerShip.centerX,Math.sin(Math.toRadians(playerShip.angle3))*playerShip.radius+playerShip.centerY);
                context.lineTo(Math.cos(Math.toRadians(playerShip.angle1))*playerShip.radius+playerShip.centerX,Math.sin(Math.toRadians(playerShip.angle1))*playerShip.radius+playerShip.centerY);    
                
   
                context.closePath();
                context.stroke();
                
                playerShip.centerX+=playerShip.velocityX;
                playerShip.centerY+=playerShip.velocityY;
            }   
            
            context.setFill(Color.WHITE);
            
            // draw asteroids 
            for(i=0;i<=asteroids.size()-1;i++){
                
                if(!asteroids.get(i).hit){
                    context.strokeOval(asteroids.get(i).centerX,asteroids.get(i).centerY,asteroids.get(i).radius,asteroids.get(i).radius);
                    
                    if(Math.pow(playerShip.centerX-asteroids.get(i).centerX,2)+Math.pow(playerShip.centerY-asteroids.get(i).centerY,2)<=Math.pow(asteroids.get(i).radius+playerShip.radius,2)){
                            
                            playerShip.hit=true;
                      
                    }
                
                    asteroids.get(i).centerX+=asteroids.get(i).velocityX;
                    asteroids.get(i).centerY+=asteroids.get(i).velocityY;
                }
            }
            
            // draw bullets 
            for(i=0;i<=bullets.size()-1;i++){
                
                if(!bullets.get(i).hit){
                    context.fillOval(bullets.get(i).centerX,bullets.get(i).centerY,bullets.get(i).radius,bullets.get(i).radius);
                    
                    for(j=0;j<=asteroids.size()-1;j++){
                        
                        if(!asteroids.get(j).hit && Math.pow(bullets.get(i).centerX-asteroids.get(j).centerX,2)+Math.pow(bullets.get(i).centerY-asteroids.get(j).centerY,2)<=Math.pow(asteroids.get(j).radius+bullets.get(i).radius,2)){
                            
                            asteroids.get(j).hit=true;
                            bullets.get(i).hit=true;
                            
                            if(asteroids.get(j).radius!=25){
                               
                                    
                                for(timesRun=1;timesRun<=2;timesRun++){
                                    

                                    angle = Math.random()*89;
                
                                    velX=Math.cos(angle)*3.2;
                                    velY=Math.sin(angle)*3.2;
                                    
                                    signX=rand.nextInt(2);
                                    signY=rand.nextInt(2);
                                    
                                    if(signX==0){
                                        velX=-velX;
                                    }
                                    if(signY==0){
                                        velY=-velY;
                                    }
                                    
                                    // medium asteroid 
                                    if(asteroids.get(j).radius==50){
                                        asteroids.add(new Asteroid(asteroids.get(j).centerX,asteroids.get(j).centerY,velX,velY,25));
            
                                
                                    }
                                    // large asteroid 
                                    else if(asteroids.get(j).radius==100){
                                        asteroids.add(new Asteroid(asteroids.get(j).centerX,asteroids.get(j).centerY,velX,velY,50));
                                    }
                                }
                            }
                        }
                    }
                    
                    bullets.get(i).centerX+=bullets.get(i).velocityX;
                    bullets.get(i).centerY+=bullets.get(i).velocityY;
                }
            }
            
            deleteObjects();
            
            if(playerShip.hit){
                startGame();
            }
        }
        
        
        
    @Override
    public void start(Stage primaryStage) {
        
        startGame();
        
       canvas.setOnMouseMoved(new EventHandler<MouseEvent>() {
           
        @Override
        public void handle(MouseEvent e) {
           
            distX=Math.abs(e.getX()-playerShip.centerX);
            distY=Math.abs(e.getY()-playerShip.centerY);
            angle = Math.atan(distY/distX);
            
            playerShip.velocityX=Math.cos(angle)*3;
            playerShip.velocityY=Math.sin(angle)*3;
            
            if(e.getX()<playerShip.centerX){
                playerShip.velocityX=-playerShip.velocityX;
            }
            if(e.getY()<playerShip.centerY){
                playerShip.velocityY=-playerShip.velocityY;
            }
        }
    });
        
        // control
	scene.addEventFilter(KeyEvent.KEY_PRESSED, key -> {
            
            if (key.getCode() == KeyCode.A ) {
		direction="left";
            }
            
	    if (key.getCode() == KeyCode.D ) {
		direction="right";
	    }
            
            if (key.getCode() == KeyCode.W) {
                
                
                if(playerCanFire){
                    
                    distX=Math.abs(Math.cos(Math.toRadians(playerShip.angle1))*playerShip.radius+playerShip.centerX-playerShip.centerX);
                    distY=Math.abs(Math.sin(Math.toRadians(playerShip.angle1))*playerShip.radius+playerShip.centerY-playerShip.centerY);
                    angle = Math.atan(distY/distX);
                    
                    velX=Math.cos(angle)*20;
                    velY=Math.sin(angle)*20;
            
                     if(Math.cos(Math.toRadians(playerShip.angle1))*playerShip.radius+playerShip.centerX<playerShip.centerX){
                        velX=-velX;
                    }
                    if(Math.sin(Math.toRadians(playerShip.angle1))*playerShip.radius+playerShip.centerY<playerShip.centerY){
                        velY=-velY;
                    }
            
                    bullets.add(new Bullet(Math.cos(Math.toRadians(playerShip.angle1))*playerShip.radius+playerShip.centerX,Math.sin(Math.toRadians(playerShip.angle1))*playerShip.radius+playerShip.centerY,velX,velY));
                    playerCanFire=false;
                
                
                    timer.schedule(new TimerTask() {

                     @Override
                     public void run() {
                            playerCanFire=true;
                        }
                    
		
                
                    },500);
                
                }
            }
        });
        
       timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                updateScreen();
            }
        },0,20);
        
       timer.scheduleAtFixedRate(new TimerTask() {

            @Override
            public void run() {
                generateAsteroids();
            }
        },0,350);
       
        
        primaryStage.setTitle("Asteroids ");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
